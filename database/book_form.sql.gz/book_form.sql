-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10 يناير 2023 الساعة 10:12
-- إصدار الخادم: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `book_form`
--

CREATE TABLE `book_form` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `guests` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `book_form`
--

INSERT INTO `book_form` (`id`, `name`, `email`, `phone`, `address`, `location`, `guests`) VALUES
(1, 'mohamed', 'mo@ham.ed', 454532454, 'berbaihll5e', 'macca', 3),
(2, 'mohamed', 'mo@jl.co', 342830482, 'djelfa', 'soudia', 2),
(3, 'mamoun', 'moe@jfd.fd', 2147483647, 'flsdfda', 'asdfa', 23),
(4, 'KHALED', 'KH@AL.ED', 2147483647, 'DJALFA', 'HOUAS', 3),
(5, 'HOUSSAM', 'Houssamains914@gmail.com', 781516519, 'jdelfa', 'MEKKA', 4),
(6, 'YACIN', 'YA@CI.N', 385345, 'BOUSADA', 'DUBAI', 3),
(8, 'ahmed ben', 'ahmed@gmail.com', 666666666, 'Ain Elbell', 'america', 2),
(9, 'lakdar', 'lakdar@gmail.com', 45151454, 'charef', 'canada', 3),
(10, 'islam', 'benaliislam17@gmail.com', 2147483647, 'algeria djelffa', 'madina', 2),
(11, 'amindfj', 'amin@gmail.com', 22555444, 'djelfa', 'oran', 1),
(12, 'lakhdar', 'lk@df.dfq', 2147483647, 'jdfsdgfhjsdgf', 'dasdha', 45454),
(13, 'fadsfasd', 'sd@Edfk.ssd', 546544646, 'fdsfsfds', 'dfhjs', 64);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_form`
--
ALTER TABLE `book_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_form`
--
ALTER TABLE `book_form`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
